package de.propra.dna.data;

public enum NukleotideDNA {
  A,T,C,G;
}
