package de.propra.dna.data;

public enum NukleotideRNA {
  A,U,C,G
}
